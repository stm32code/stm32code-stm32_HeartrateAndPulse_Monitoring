#!/usr/bin/env bash
#python3 controller.py --dht11 0,1 --relay 2 --loop 0
python3 controller.py --dht11 37 --relay 12 --max30102 7 --loop 10